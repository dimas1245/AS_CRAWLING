<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Proses Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 60px auto;
            background: #ffffff;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        h1 {
            font-size: 22px;
            margin-bottom: 15px;
            color: #333;
        }

        form {
            margin-bottom: 30px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="Preprocessing.php" method="get">		
            <h1>Tahap PreProcessing Data</h1>
            <input type="submit" value="Proses Pembersihan Data">
        </form>
        <form action="labeling_2212500041.php" method="get">		
            <h1>Tahap Pelabelan Data</h1>
            <input type="submit" value="Proses Pelabelan Data">
        </form>
    </div>
</body>
</html>

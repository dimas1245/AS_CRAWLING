<?php
$prefix = array(
  'tidak',
  'bukan',
  'salah'
);

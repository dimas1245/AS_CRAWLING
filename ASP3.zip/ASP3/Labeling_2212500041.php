<!DOCTYPE html>
<html>
<head>
	<title>Tahap Labelisasi Data</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
	<script type="text/javascript" src="bootstrap/js/jquery.js"></script>
	<script type="text/javascript" src="bootstrap/js/bootstrap.js"></script>
</head>
<body>
<table class="table table-bordered table-striped">  
<td colspan="3">
      <button onclick="goBack()">Kembali Ke Form Input Link 2212500041</button>
        <script>
            function goBack() {
                window.history.back();
            }
        </script>
        </td>
</table>    
<br>

<?php
include 'Koneksi.php';
require_once __DIR__ . '/autoload.php';
$sentiment = new \PHPInsight\Sentiment();


$i=1;
$sql = "SELECT * FROM preprocessing_2212500041_lexicon where length(id)!=0";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    echo "Data Tidak Ditemukan";
}else{	
    ?>	
    <table border="1" cellpadding="1" cellspacing="1" bgcolor="#999999">
    <thead>    
    <tr>
      <td colspan="4"><strong>Daftar Labelisasi Dataddd</strong></td>
    </tr>
    <tr bgcolor="#CCCCCC">
    <th>No.</th>
    <th>Data Bersih</th>
    <th>Arah Sentimen</th>
    </tr>
    </thead>
    <?php 
    while($d = mysqli_fetch_array($result)){
        //$data_bersih = $d['data_bersih'];
        $data_bersih = $d['data_bersih'];
        $id = $d['id'];

        $strings = array(
            1 => $data_bersih,
        );
    
        foreach ($strings as $string) {
    
            // calculations:
            $scores = $sentiment->score($string);
            $class = $sentiment->categorise($string);
    
            ?>       
            <tr bgcolor="#FFFFFF">
                <td><?php echo $i; ?></td>
                <td><?php echo $data_bersih; ?></td>
                <td><?php echo $class; ?></td>
            <?php 

            $sql = "SELECT * FROM preprocessing_2212500041_lexicon where id='$id'";
            $result1 = $conn->query($sql);

            if ($result1->num_rows != 0) {
                $q = "UPDATE preprocessing_2212500041_lexicon set kategori='$class'
                            where id='$id'";
                
                $result1 = mysqli_query($conn,$q);
            }	

            $i++;
        }
    
    ?>       
        </tr>
 
    <?php 
    }
}
?>
</body>
</html>

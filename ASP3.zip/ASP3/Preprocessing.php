<!DOCTYPE html>
<html>
<head>
    <title>Preprocessing Data</title>
</head>
<body>
    <h3><a href="FormLoadFile.php">Kembali ke Form Awal 2212500041</a></h3>
    <br>
</body>
</html>

<?php
include 'Koneksi.php';
include "stopword.php";
require_once __DIR__ . '/sastrawi/vendor/autoload.php';

$stemmerFactory = new \Sastrawi\Stemmer\StemmerFactory();
$stemmer  = $stemmerFactory->createStemmer();

echo "<br>";

$sql = "SELECT * FROM preprocessing_2212500041 WHERE LENGTH(data_mentah) != 0";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    echo "Data Tidak Ditemukan";
} else {    
    ?>    
    <table border="1" cellpadding="1" cellspacing="1" bgcolor="#999999">
        <tr bgcolor="#CCCCCC">
            <th>ID</th>
            <th>Konten</th>
            <th>Case Folding</th>
            <th>Hapus Simbol</th>
            <th>Filter Slang Word</th>
            <th>Filter Stopword</th>
            <th>Stemming</th>
            <th>Tokenisasi</th>
        </tr>
    <?php 

    while ($d = mysqli_fetch_array($result)) {
        $id = $d['id'];
        $comment = trim($d['data_mentah']);

        // 1. Case Folding (Konversi ke huruf kecil)
        $cf = strtolower($comment);

        // 2. Penghapusan Simbol (Symbol Removal)
        $cf = preg_replace('/<.*?>/', ' ', $cf); // Hapus tag HTML
        $cf = preg_replace('/(https?:\/\/[^\s]+)/', ' ', $cf); // Hapus URL
        $cf = preg_replace('/[^a-zA-Z\s]/', '', $cf); // Hapus karakter selain huruf dan spasi
        $cf = str_replace('nbsp', ' ', $cf); // Ganti &nbsp dengan spasi
        $cf = trim($cf);

        // 3. Konversi Slang Word dan koreksi kata baku
        $words = explode(' ', $cf);
        foreach ($words as &$word) {
            $query = "SELECT kata_baku FROM slangword_2212500041 WHERE kata_tbaku=?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("s", $word);
            $stmt->execute();
            $stmt->bind_result($kata_baku);
            if ($stmt->fetch()) {
                $word = $kata_baku; // Ganti slang dengan kata baku
            }
            $stmt->close();
        }
        $slangword = implode(' ', $words);

        // 4. Stopword Removal
        $filtered_words = array_diff(explode(' ', $slangword), $stopwords);
        $stopword = implode(' ', $filtered_words);

        // 5. Stemming
        $stemming = $stemmer->stem($stopword);

        // 6. Tokenisasi
        $tokenized_words = explode(' ', $stemming);
        $tokenized_words = array_map('trim', $tokenized_words); // Hilangkan spasi berlebih
        $tokenisasi = implode(', ', $tokenized_words);

        // Tampilkan hasil
        ?>
        <tr bgcolor="#FFFFFF">
            <td><?php echo $id; ?></td>
            <td><?php echo $comment; ?></td>
            <td><?php echo $cf; ?></td>
            <td><?php echo $cf; ?></td>
            <td><?php echo $slangword; ?></td>
            <td><?php echo $stopword; ?></td>
            <td><?php echo $stemming; ?></td>
            <td><?php echo $tokenisasi; ?></td>
        </tr>
        <?php 

        // Simpan hasil ke database (gunakan prepared statement)
        $query = "UPDATE preprocessing_2212500041 
                  SET p_cf=?, p_rsimbol=?, p_tokenisasi=?, p_slangword=?, 
                      p_stopword=?, p_stemming=?, data_bersih=? 
                  WHERE id=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssssi", $cf, $cf, $tokenisasi, $slangword, $stopword, $stemming, $stemming, $id);
        $stmt->execute();
        $stmt->close();
    }
    ?>
    </table>

    <?php
    // Hitung jumlah rekaman yang diproses
    $sql2 = "SELECT COUNT(*) as jml FROM preprocessing_2212500041 WHERE LENGTH(data_mentah) != 0";
    $result2 = $conn->query($sql2);
    $d = mysqli_fetch_array($result2);
    $id = $d['jml'];

    echo "<h1>Preprocessing $id Rekaman Data Berhasil</h1>";
}
?>
